from django.contrib import admin
from .models import Patient


class Adminpatient(admin.ModelAdmin):
    list_display = ['name','age','gender']

# Register your models here.
admin.site.register(Patient,Adminpatient)