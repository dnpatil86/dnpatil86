from django.shortcuts import render,HttpResponseRedirect
from .models import Patient
from django.http import HttpResponse

# Create your views here.\
def index(request):
    return render(request,'index.html')

def p_form(request):
    if request.method=='GET':
        return render(request,'registration.html')
    else :
        postData = request.POST
        name = postData.get('name')
        age = postData.get('age')
        gender=postData.get('gender')
        symptoms=postData.get('symptoms')
        prescription=postData.get('prescription')
        date=postData.get('date')

        patient=Patient(name=name,
                         age=age,
                         gender=gender,
                         symptoms=symptoms,
                         prescription=prescription,
                         date=date)
        #validation
        error_message= None
        message= 'Add Patient'
        if (not name):
            error_message= "Name Required"
        elif (not age):
            error_message= "Age Required"
        elif (not gender):
            error_message= "Gender Required"
        elif (not symptoms):
            error_message= "Sympoms Required"
        elif (not prescription):
            error_message= "Prescription Required"
        elif (not date):
            error_message= "Date Required"

         #saving
        if not error_message:
             patient.save()
             return render(request,'index.html', {'data':message})
        else:
            return render(request,'reqistration.html',{'error':error_message})

def p_view(request):
       patient=Patient.get_all_patients();
       return render(request,'patientview.html',{'Patients':patient})

def delete_data(request,id):
    if request.method=='POST':
            pi = Patient.objects.get(id=id)
            pi.delete()
            return HttpResponseRedirect('/')


